var ssCountdownDefaultOptions = ssCountdownDefaultOptions || {};
ssCountdownDefaultOptions.secondsColor 	= 	"#11c8ea";
ssCountdownDefaultOptions.minutesColor 	= 	"#ff5153";
ssCountdownDefaultOptions.hoursColor 	= 	"#23d0a2";
ssCountdownDefaultOptions.daysColor 	= 	"#f9b401";
ssCountdownDefaultOptions.date 		= 	"2021-08-11";
ssCountdownDefaultOptions.time 		= 	"01:00:00";
ssCountdownDefaultOptions.timezone 		= 	"GMT+07:00";